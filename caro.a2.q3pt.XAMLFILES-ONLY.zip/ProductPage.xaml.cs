namespace caro.a2.q3pt;

public partial class ProductPage : ContentPage
{
    public ProductPage()
    {
        InitializeComponent();

    }
   
}