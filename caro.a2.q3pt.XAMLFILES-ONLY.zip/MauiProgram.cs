﻿using Microsoft.Extensions.Logging;

namespace caro.a2.q3pt
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                    fonts.AddFont("IosevkaSS14-Bold.ttf", "IosevkaSS14-Bold");
                    fonts.AddFont("IosevkaSS14-BoldItalic.ttf", "IosevkaSS14-BoldItalic");
                    fonts.AddFont("IosevkaSS14-Regular.ttf", "IosevkaSS14");
                    fonts.AddFont("IosevkaSS14-Italic.ttf", "IosevkaSS14-Italic");
                    fonts.AddFont("InterVariable.ttf", "Inter");
                });

#if DEBUG
    		builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
