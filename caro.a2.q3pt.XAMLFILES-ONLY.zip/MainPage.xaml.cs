﻿namespace caro.a2.q3pt
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        
    }

}
