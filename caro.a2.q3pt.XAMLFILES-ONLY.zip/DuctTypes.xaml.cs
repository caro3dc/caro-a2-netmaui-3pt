namespace caro.a2.q3pt;

public partial class DuctTypes : ContentPage
{
	public DuctTypes()
	{
		InitializeComponent();
	}
}