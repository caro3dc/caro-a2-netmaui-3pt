namespace caro.a2.q3pt;

public partial class ContactPage : ContentPage
{
	public ContactPage()
	{
		InitializeComponent();
	}
}