

namespace caro.a2.q3pt;
public partial class ServicesPage : ContentPage
{
	public ServicesPage()
	{
		InitializeComponent();
	}

    private void Button_Clicked(object sender, EventArgs e)
    {
        servbtn.Text = "This company doesn't actually exist :(";
    }
}