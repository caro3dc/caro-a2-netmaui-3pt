namespace caro.a2.q3pt;

public partial class AboutPage : ContentPage
{
	public AboutPage()
	{
		InitializeComponent();
	}
	int count = 0;
    private void SwitchLang_Clicked(object sender, EventArgs e)
    {
		count++;
		if(count % 2 == 1)
		{

			Nui.Text = "Nui Gion";

			One.Text = "Pétred o Runréin ut hemnér es ińla 2008 in viegou duis né Ioan ia Lamáir id lan hettavrosau lunau ci Arhanagion Errýimeint Hónérided sa Tielohańa.";

            Two.Text = "Ivalt scaro réu o monopoli int corpurat trógrasat la industrie HVAC sa aréa-cras Viride-Haravas néid vennuisal rio lat róinsciat ot préiśiet trótielvadat cycsiiustiviradat cnagi serviciet cycspirodat, ia utvos ivalt aplian réu ot cmilat réus int installatio, ŋivgus, ia maintenatio es systémet hevrunat.";

			Three.Text = "Pos ińlat 24, Runréin ainis sié iśt corpurat HVACat trógrasat sa aréa idmi ras ci paltraugat 200, iató vetanalt ni si corpur trógras es Nocéudsvale hónespaltraugatad.";

			Four.Text = "Hes davi śti, maintenais gio ve Runréin o ýste gios la hessumi, la ŋarras ot cyvléisiat, ia la nahuid o ventilatio tópólnad lot róinsciat gios ar.";

			Thanks.Text = "Lo svesór áŋriin gion vaśive!";

            SwitchLang.Text = "In English / Ve Angliácid";

        } else
		{
            Nui.Text = "About Us";

            One.Text = "Runréin was founded in the summer of 2008 by two friends, Ioan and Lamáir, who were fresh graduates from the National Builders' University in Tielohańa.";

            Two.Text = "They wanted to break the monopoly of big corporations on the HVAC industry in the greater Viride-Haravas area, who were offering customers unjustifiably high prices in exchange for subpar services, and at the same time apply their skills in installation, repair, and maintenance of ventilation systems.";

            Three.Text = "24 years on, Runréin is now the one of the biggest HVAC companies in the area, with over 200 employees, and it has also grown to be Noceudshire's biggest completely employee-owned company.";

            Four.Text = "Till this day, we at Runréin maintain our commitment to service, exceeding expectations, and providing better ventilation for all our customers.";

            Thanks.Text = "Thank you for continuing to support us!";

			SwitchLang.Text = "In Sevdenian / Ve Séudeniad";
        }
    }
}